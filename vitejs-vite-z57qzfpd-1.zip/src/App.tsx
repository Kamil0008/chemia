// @ts-nocheck
import { useState, useEffect, useRef } from "react";

const RARITY = {
  common:     { label:"Pospolity",    color:"#b0c3d9", glow:"#b0c3d9", bg:"#1a2a3a" },
  uncommon:   { label:"Niepospolity", color:"#5dade2", glow:"#5dade2", bg:"#0d2035" },
  rare:       { label:"Rzadki",       color:"#a855f7", glow:"#c084fc", bg:"#1e0d35" },
  epic:       { label:"Epicki",       color:"#ec4899", glow:"#f472b6", bg:"#2d0d20" },
  legendary:  { label:"Legendarny",   color:"#f59e0b", glow:"#fbbf24", bg:"#2d1f00" },
  contraband: { label:"Zakazany",     color:"#ef4444", glow:"#ff6b6b", bg:"#2d0000" },
};

const ELEMENTS = [
  { symbol:"H",  name:"Wodór",      z:1,  rarity:"common",     mass:"1.008",   group:"Niemetal",          desc:"Najlżejszy pierwiastek we wszechświecie. Pali się jasnym płomieniem. Stanowi 75% masy widzialnej materii." },
  { symbol:"O",  name:"Tlen",       z:8,  rarity:"common",     mass:"15.999",  group:"Niemetal",          desc:"Niezbędny do życia i spalania. Stanowi 21% atmosfery Ziemi. Odkryty przez Scheelego w 1771 r." },
  { symbol:"C",  name:"Węgiel",     z:6,  rarity:"common",     mass:"12.011",  group:"Niemetal",          desc:"Podstawa życia organicznego. Diament i grafit to dwie formy krystaliczne węgla." },
  { symbol:"N",  name:"Azot",       z:7,  rarity:"common",     mass:"14.007",  group:"Niemetal",          desc:"Stanowi 78% powietrza. W ciekłej postaci (-196°C) służy do głębokiego mrożenia i kriogeniki." },
  { symbol:"Na", name:"Sód",        z:11, rarity:"common",     mass:"22.990",  group:"Metal alkaliczny",  desc:"Srebrny metal gwałtownie reagujący z wodą. Składnik soli kuchennej (NaCl). Pali się żółtym płomieniem." },
  { symbol:"Fe", name:"Żelazo",     z:26, rarity:"common",     mass:"55.845",  group:"Metal przejściowy", desc:"Najpowszechniejszy metal na Ziemi. Rdzeń naszej planety jest z żelaza. Podstawa cywilizacji industrialnej." },
  { symbol:"Ca", name:"Wapń",       z:20, rarity:"common",     mass:"40.078",  group:"Metal ziem alk.",   desc:"Budulec kości i zębów. Podstawowy składnik wapienia, marmuru i kredy. Niezbędny dla skurczów mięśni." },
  { symbol:"K",  name:"Potas",      z:19, rarity:"common",     mass:"39.098",  group:"Metal alkaliczny",  desc:"Vital dla nerwów i mięśni. Reaguje eksplozywnie z wodą. Fioletowy płomień to jego znak rozpoznawczy." },
  { symbol:"Si", name:"Krzem",      z:14, rarity:"uncommon",   mass:"28.085",  group:"Półmetal",          desc:"Podstawa elektroniki i mikroprocesorów. Daje nazwę Dolinie Krzemowej. Drugi najczęstszy pierwiastek w skorupie." },
  { symbol:"S",  name:"Siarka",     z:16, rarity:"uncommon",   mass:"32.06",   group:"Niemetal",          desc:"Żółty pierwiastek o charakterystycznym zapachu jaj. Używana w prochu strzelniczym od wieków." },
  { symbol:"Cl", name:"Chlor",      z:17, rarity:"uncommon",   mass:"35.45",   group:"Halogen",           desc:"Zielonkawy toksyczny gaz. W I wojnie światowej używany jako broń chemiczna. Dziś dezynfekuje wodę." },
  { symbol:"Mg", name:"Magnez",     z:12, rarity:"uncommon",   mass:"24.305",  group:"Metal ziem alk.",   desc:"Spala się oślepiającym białym blaskiem (3000°C). Lekki metal lotniczy i kosmiczny." },
  { symbol:"Al", name:"Glin",       z:13, rarity:"uncommon",   mass:"26.982",  group:"Metal",             desc:"Najczęściej używany metal nieżelazny. Lekki, odporny na korozję. 8% masy skorupy ziemskiej." },
  { symbol:"P",  name:"Fosfor",     z:15, rarity:"uncommon",   mass:"30.974",  group:"Niemetal",          desc:"Biały fosfor świeci w ciemności i samozapalnie. Niezbędny składnik DNA, RNA i cząsteczki ATP." },
  { symbol:"Cu", name:"Miedź",      z:29, rarity:"uncommon",   mass:"63.546",  group:"Metal przejściowy", desc:"Doskonały przewodnik elektryczności. Używana przez człowieka od 10 000 lat. Brąz = miedź + cyna." },
  { symbol:"Zn", name:"Cynk",       z:30, rarity:"uncommon",   mass:"65.38",   group:"Metal przejściowy", desc:"Chroni stal przed korozją (galwanizacja). Niezbędny mikroelement odpornościowy dla organizmu." },
  { symbol:"Ti", name:"Tytan",      z:22, rarity:"rare",       mass:"47.867",  group:"Metal przejściowy", desc:"Wytrzymalszy od stali, a przy tym znacznie lżejszy. Metal ery kosmicznej — implanty i samoloty." },
  { symbol:"Ni", name:"Nikiel",     z:28, rarity:"rare",       mass:"58.693",  group:"Metal przejściowy", desc:"Twardy, odporny na korozję. Składnik monet, baterii niklowo-kadmowych i stali nierdzewnej." },
  { symbol:"Co", name:"Kobalt",     z:27, rarity:"rare",       mass:"58.933",  group:"Metal przejściowy", desc:"Daje niebieskie zabarwienie szkłu i porcelanie od starożytności. Klucz w bateriach litowo-jonowych." },
  { symbol:"Cr", name:"Chrom",      z:24, rarity:"rare",       mass:"51.996",  group:"Metal przejściowy", desc:"Nadaje połysk i twardość stali nierdzewnej. Twardość 8.5 w skali Mohsa. Zielone kamienie szlachetne." },
  { symbol:"Mn", name:"Mangan",     z:25, rarity:"rare",       mass:"54.938",  group:"Metal przejściowy", desc:"Kluczowy w produkcji stali i baterii alkalicznych. Silny utleniacz — nadmanganian to sól purpurowa." },
  { symbol:"Se", name:"Selen",      z:34, rarity:"rare",       mass:"78.971",  group:"Niemetal",          desc:"Fotoprzewodnik w kserokopiarkach i panelach słonecznych. Pierwiastek śladowy chroniący DNA." },
  { symbol:"Ge", name:"German",     z:32, rarity:"rare",       mass:"72.630",  group:"Półmetal",          desc:"Istnienie germanium przewidział Mendelejew zanim go odkryto! Optyka podczerwieni i światłowody." },
  { symbol:"Pt", name:"Platyna",    z:78, rarity:"epic",       mass:"195.08",  group:"Metal szlachetny",  desc:"Odporniejsza od złota na wszelkie korozje. Katalizator spalin samochodowych. Symbol czystości." },
  { symbol:"Pd", name:"Pallad",     z:46, rarity:"epic",       mass:"106.42",  group:"Metal szlachetny",  desc:"Pochłania wodór 900-krotność swojej objętości! Droższy od złota. Kluczowy w katalizatorach." },
  { symbol:"Rh", name:"Rod",        z:45, rarity:"epic",       mass:"102.91",  group:"Metal szlachetny",  desc:"Najdroższy metal świata — ~$14 000 za uncję! Nadaje lustrzyskie wykończenie biżuterii." },
  { symbol:"Ir", name:"Iryd",       z:77, rarity:"epic",       mass:"192.22",  group:"Metal szlachetny",  desc:"Najtwardszy metal znany człowiekowi. Warstwa irydowa w skałach to ślad uderzenia asteroidy 66 mln lat temu." },
  { symbol:"Os", name:"Osm",        z:76, rarity:"epic",       mass:"190.23",  group:"Metal szlachetny",  desc:"Najgęstszy pierwiastek — 22.6 g/cm³. Jego tlenki (OsO₄) są niezwykle trujące i lotne." },
  { symbol:"Au", name:"Złoto",      z:79, rarity:"legendary",  mass:"196.97",  group:"Metal szlachetny",  desc:"Symbol bogactwa od tysiącleci. Nie rdzewieje, nie koroduje. Używane w elektronice kosmicznej." },
  { symbol:"Ag", name:"Srebro",     z:47, rarity:"legendary",  mass:"107.87",  group:"Metal szlachetny",  desc:"Najlepszy przewodnik elektryczności ze wszystkich metali. Działa bakteriobójczo. Wampiry nienawidzą." },
  { symbol:"Hg", name:"Rtęć",       z:80, rarity:"legendary",  mass:"200.59",  group:"Metal przejściowy", desc:"Jedyny ciekły metal w temperaturze pokojowej. Toksyczny. Używany w termometrach i lampach UV." },
  { symbol:"Li", name:"Lit",        z:3,  rarity:"legendary",  mass:"6.941",   group:"Metal alkaliczny",  desc:"Najlżejszy metal. Napędza baterie naszej cywilizacji. W psychiatrii stabilizuje nastrój." },
  { symbol:"He", name:"Hel",        z:2,  rarity:"contraband", mass:"4.003",   group:"Gaz szlachetny",    desc:"Drugi najlżejszy pierwiastek. Nie reaguje z NICZYM. Zamienia głos w piszczące baloniki. Helowe słońce." },
  { symbol:"Ra", name:"Rad",        z:88, rarity:"contraband", mass:"226",     group:"Metal ziem alk.",   desc:"Odkryty przez Marię Curie. Świeci niebiesko w ciemności. Śmiertelnie radioaktywny. Nobel 1911." },
  { symbol:"U",  name:"Uran",       z:92, rarity:"contraband", mass:"238.03",  group:"Aktynowiec",        desc:"Paliwo reaktorów jądrowych i bomb atomowych. Promieniuje przez miliardy lat. Cięższy od ołowiu." },
  { symbol:"Pu", name:"Pluton",     z:94, rarity:"contraband", mass:"244",     group:"Aktynowiec",        desc:"Stworzony przez człowieka w reaktorach. Bomba Nagasaki zawierała zaledwie 6 kg plutonu." },
  { symbol:"Xe", name:"Ksenon",     z:54, rarity:"contraband", mass:"131.29",  group:"Gaz szlachetny",    desc:"Silnik jonowy sond kosmicznych działa na ksenonie. Najdroższy gaz szlachetny — anestezja przyszłości." },
];

const CASES = [
  { id:"lab",      name:"Skrzynka Laboratorium", subtitle:"Podstawowe reagenty",   icon:"⚗️", price:1,  color:"#5dade2", rarities:["common","uncommon"],          weights:{common:72,uncommon:28} },
  { id:"metals",   name:"Skrzynka Metali",        subtitle:"Metale i stopy",         icon:"🔩", price:3,  color:"#a855f7", rarities:["uncommon","rare","epic"],      weights:{uncommon:55,rare:35,epic:10} },
  { id:"noble",    name:"Skrzynka Szlachetna",    subtitle:"Metale szlachetne",      icon:"💎", price:8,  color:"#f59e0b", rarities:["rare","epic","legendary"],     weights:{rare:55,epic:30,legendary:15} },
  { id:"radioact", name:"Skrzynka Radioaktywna",  subtitle:"⚠ Skrajnie niebezpieczna",icon:"☢️",price:15, color:"#ef4444", rarities:["legendary","contraband"],     weights:{legendary:70,contraband:30} },
];

const RECIPES = [
  { inputs:["H","H","O"],       name:"Woda",             formula:"H₂O",    emoji:"💧", desc:"Cząsteczka życia. Pokrywa 71% powierzchni Ziemi. Bez niej życie niemożliwe." },
  { inputs:["Na","Cl"],         name:"Sól kuchenna",     formula:"NaCl",   emoji:"🧂", desc:"Podstawowa przyprawa i konserwant. Znana człowiekowi od ponad 8000 lat." },
  { inputs:["Fe","C"],          name:"Stal",              formula:"Fe+C",   emoji:"⚙️", desc:"Stop żelaza z węglem. Fundament rewolucji przemysłowej i współczesnej architektury." },
  { inputs:["H","O"],           name:"Woda Utleniona",   formula:"H₂O₂",   emoji:"🫧", desc:"Silny utleniacz dezynfekujący rany. W 30% koncentracji — potężny środek bielący." },
  { inputs:["N","H"],           name:"Amoniak",          formula:"NH₃",    emoji:"💨", desc:"Ostry zapach drażniący. Synteza Habera-Boscha pozwala żywić miliard ludzi." },
  { inputs:["C","O"],           name:"Dwutlenek węgla",  formula:"CO₂",    emoji:"🌫️", desc:"Gaz cieplarniany. Nadaje musowanie napojom. Suchy lód to zamrożone CO₂." },
  { inputs:["Si","O"],          name:"Kwarc",             formula:"SiO₂",   emoji:"🔮", desc:"Krystaliczny dwutlenek krzemu. Budulec szkła, procesorów i kryształów górskich." },
  { inputs:["Ca","C","O"],      name:"Wapień",            formula:"CaCO₃",  emoji:"🪨", desc:"Skała osadowa budująca góry. Marmur, kreda i muszle to formy CaCO₃." },
  { inputs:["Au","Ag"],         name:"Elektrum",          formula:"Au-Ag",  emoji:"✨", desc:"Naturalny stop złota i srebra. Na nim wybito pierwsze monety w historii (VII w. p.n.e.)." },
  { inputs:["Fe","S"],          name:"Piryt",              formula:"FeS₂",   emoji:"🌟", desc:'Złoto głupców — błyszczy jak złoto, ale nim nie jest. Crystals "fool\'s gold".' },
  { inputs:["Na","H","C","O"],  name:"Soda oczyszczona", formula:"NaHCO₃", emoji:"🫗", desc:"Klucz do wypieków — reaguje z kwasem wytwarzając CO₂. Gasi też pożary klas B." },
  { inputs:["Cu","Zn"],         name:"Mosiądz",            formula:"CuZn",   emoji:"🎺", desc:"Stop miedzi i cynku. Instrumenty dęte, łuski nabojów i klamki od stuleci." },
  { inputs:["Ti","Al"],         name:"Stop Lotniczy",     formula:"Ti-Al",  emoji:"✈️", desc:"Superlekki stop do zastosowań aerospace. Łopatki turbin i implanty biomedyczne." },
  { inputs:["He","Xe"],         name:"Gaz Laserowy",     formula:"He+Xe",  emoji:"🌈", desc:"Mieszanina do lamp i laserów. Wytwarza intensywne widmo spektralne." },
  { inputs:["U","Pu"],          name:"Paliwo Jądrowe",   formula:"U-Pu",   emoji:"⚛️", desc:"Paliwo reaktorów IV generacji. 1 kg = energia równoważna 3 000 000 kg węgla." },
  { inputs:["Au","Hg"],         name:"Amalgamat",         formula:"Au-Hg",  emoji:"🪙", desc:"Historyczna metoda wydobycia złota. Rtęć rozpuszcza złoto, potem ją odparowują." },
  { inputs:["Li","Co","O"],     name:"Bateria Litowa",   formula:"LiCoO₂", emoji:"🔋", desc:"Katoda akumulatora litowo-jonowego. Napędza smartfony, laptopy i samochody EV." },
];

function weightedPick(caseObj) {
  const pool = ELEMENTS.filter(e => caseObj.rarities.includes(e.rarity));
  const weighted = [];
  pool.forEach(e => {
    const w = caseObj.weights[e.rarity] || 1;
    for (let i = 0; i < w; i++) weighted.push(e);
  });
  return weighted[Math.floor(Math.random() * weighted.length)];
}

function buildStrip(winner, caseObj) {
  const pool = ELEMENTS.filter(e => caseObj.rarities.includes(e.rarity));
  const strip = Array.from({length:56}, () => pool[Math.floor(Math.random()*pool.length)]);
  strip[41] = winner;
  return strip;
}

function RarityBadge({ rarity, small }) {
  const r = RARITY[rarity];
  return (
    <span style={{
      background: r.bg,
      color: r.color,
      border: `1px solid ${r.color}`,
      borderRadius: "4px",
      padding: small ? "1px 5px" : "2px 8px",
      fontSize: small ? "9px" : "10px",
      fontWeight: 700,
      letterSpacing: "0.08em",
      whiteSpace: "nowrap",
    }}>{r.label.toUpperCase()}</span>
  );
}

function ElCard({ el, size="md", selected, onClick, dimmed }) {
  const r = RARITY[el.rarity];
  const dim = { sm:{box:"62px",sym:"17px",z:"8px"}, md:{box:"92px",sym:"28px",z:"9px"}, lg:{box:"116px",sym:"36px",z:"10px"} }[size];
  return (
    <div onClick={onClick} style={{
      width:dim.box, height:dim.box,
      background: selected ? `radial-gradient(circle, ${r.bg} 0%, #080810 100%)` : r.bg,
      border:`2px solid ${selected ? r.color : r.color+"88"}`,
      borderRadius:"8px",
      display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center",
      cursor: onClick ? "pointer" : "default",
      boxShadow: selected ? `0 0 20px ${r.glow}, 0 0 50px ${r.glow}44` : `0 0 8px ${r.color}33`,
      transition:"all 0.2s",
      opacity: dimmed ? 0.3 : 1,
      transform: selected ? "scale(1.1)" : "scale(1)",
      flexShrink:0, position:"relative", overflow:"hidden",
    }}>
      <div style={{position:"absolute",top:0,right:0,width:"35%",height:"3px",background:r.color}} />
      <div style={{fontSize:dim.sym,fontWeight:800,color:r.color,fontFamily:"monospace",lineHeight:1}}>{el.emoji||el.symbol}</div>
      {size!=="sm" && <div style={{fontSize:dim.z,color:"#888",marginTop:"2px"}}>{el.z}</div>}
      {size==="lg" && <div style={{fontSize:"10px",color:"#666",marginTop:"2px",maxWidth:"90px",textAlign:"center",lineHeight:1.2}}>{el.name}</div>}
    </div>
  );
}

function CaseCardItem({ c, coins, onOpen }) {
  const [hov, setHov] = useState(false);
  return (
    <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)} style={{
      background:hov?`linear-gradient(145deg,#0d0d1a,${c.color}18)`:"#0d0d1a",
      border:`1px solid ${hov?c.color:c.color+"33"}`,
      borderRadius:"16px", padding:"24px 20px",
      display:"flex",flexDirection:"column",alignItems:"center",gap:"10px",
      minWidth:"200px",flex:"1 1 190px",
      transition:"all 0.3s",
      boxShadow:hov?`0 0 32px ${c.color}44`:"none",
      cursor:"default",
    }}>
      <div style={{fontSize:"48px",filter:hov?`drop-shadow(0 0 14px ${c.color})`:"none",transition:"filter 0.3s"}}>{c.icon}</div>
      <div style={{fontWeight:700,fontSize:"14px",color:"#fff",textAlign:"center"}}>{c.name}</div>
      <div style={{fontSize:"11px",color:"#666",textAlign:"center"}}>{c.subtitle}</div>
      <div style={{display:"flex",flexWrap:"wrap",gap:"4px",justifyContent:"center"}}>
        {c.rarities.map(r=><RarityBadge key={r} rarity={r} small />)}
      </div>
      <button onClick={()=>onOpen(c)} disabled={coins<c.price} style={{
        marginTop:"6px",
        background:coins>=c.price?`linear-gradient(135deg,${c.color}cc,${c.color}66)`:"#0a0a18",
        border:`1px solid ${c.color}`,
        color:coins>=c.price?"#fff":"#444",
        borderRadius:"8px",padding:"8px 22px",
        fontWeight:700,fontSize:"13px",
        cursor:coins>=c.price?"pointer":"not-allowed",
        letterSpacing:"0.05em",
        transition:"all 0.2s",
      }}>🧪 Otwórz — {c.price} Ag</button>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("cases");
  const [coins, setCoins] = useState(30);
  const [inventory, setInventory] = useState([]);
  const [phase, setPhase] = useState("idle"); // idle | spinning | reveal
  const [strip, setStrip] = useState([]);
  const [winner, setWinner] = useState(null);
  const [activeCase, setActiveCase] = useState(null);
  const [craftSlots, setCraftSlots] = useState([null,null,null,null]);
  const [craftResult, setCraftResult] = useState(null);
  const [crafting, setCrafting] = useState(false);
  const stripRef = useRef(null);
  const containerRef = useRef(null);
  const animRef = useRef(null);
  const audioCtxRef = useRef(null);
  const lastTickCard = useRef(-1);
  const [invFilter, setInvFilter] = useState("all");

  const getAudioCtx = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtxRef.current.state === "suspended") {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  };

  const playTick = (speed) => {
    try {
      const ctx = getAudioCtx();
      const now = ctx.currentTime;
      const sampleRate = ctx.sampleRate;

      // Krótki plik PCM — ostry "klik" jak w CS:GO
      const len = Math.floor(sampleRate * 0.025); // 25ms
      const buf = ctx.createBuffer(1, len, sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) {
        const t = i / len;
        // Szybki atak, szybki decay — brzmi jak stukanie
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 6) * 1.5;
      }

      // Filtr bandpass → metaliczny klik
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.value = 3500 + Math.random() * 800;
      filter.Q.value = 1.5;

      const gainNode = ctx.createGain();
      // Głośniej gdy szybko, ciszej gdy zwalnia
      const vol = Math.max(0.05, Math.min(0.5, 0.05 + speed * 0.6));
      gainNode.gain.setValueAtTime(vol, now);

      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(ctx.destination);
      src.start(now);
    } catch(e) {}
  };

  const playReveal = (rarity) => {
    try {
      const ctx = getAudioCtx();
      const notes = {
        common:     [440, 554, 659],
        uncommon:   [494, 622, 740],
        rare:       [523, 659, 784, 988],
        epic:       [587, 740, 880, 1047],
        legendary:  [659, 831, 988, 1175, 1319],
        contraband: [392, 494, 622, 740, 880, 1047],
      }[rarity] || [440, 554, 659];

      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = i % 2 === 0 ? "sine" : "triangle";
        osc.frequency.value = freq;
        const t = ctx.currentTime + i * 0.11;
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.15, t + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.55);
        osc.start(t); osc.stop(t + 0.6);
      });

      // bass thud
      const osc2 = ctx.createOscillator();
      const g2 = ctx.createGain();
      osc2.connect(g2); g2.connect(ctx.destination);
      osc2.type = "sine";
      osc2.frequency.setValueAtTime(120, ctx.currentTime);
      osc2.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.3);
      g2.gain.setValueAtTime(0.3, ctx.currentTime);
      g2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc2.start(ctx.currentTime); osc2.stop(ctx.currentTime + 0.5);
    } catch(e) {}
  };

  const openCase = (c) => {
    if (coins < c.price || phase !== "idle") return;
    // Inicjalizuj AudioContext podczas gestu użytkownika
    getAudioCtx();
    setCoins(p => p - c.price);
    const won = weightedPick(c);
    const s = buildStrip(won, c);
    setStrip(s);
    setWinner(won);
    setActiveCase(c);
    setPhase("spinning");
    setTab("opening");
  };

  useEffect(() => {
    if (phase !== "spinning") return;
    lastTickCard.current = -1;
    // Card width = 94px, gap = 4px → stride = 98px per card
    const STRIDE = 98;
    const CARD_W = 94;
    const WINNER_IDX = 41;
    const containerHalf = containerRef.current
      ? containerRef.current.getBoundingClientRect().width / 2
      : 200;
    // Center of winner card aligned to container center
    const target = WINNER_IDX * STRIDE + CARD_W / 2 - containerHalf;
    let start = null;
    const DURATION = 4800;
    const ease = t => 1 - Math.pow(1 - t, 4);
    let lastPos = 0;
    const frame = (ts) => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / DURATION, 1);
      const pos = ease(p) * target;
      if (stripRef.current) stripRef.current.style.transform = `translateX(-${pos}px)`;

      // Tick gdy nowa karta wjeżdża pod środkową linię
      // Środek kontenera w układzie scrolla = pos + containerHalf
      const markerInStrip = pos + containerHalf;
      const cardUnderMarker = Math.floor(markerInStrip / STRIDE);
      if (cardUnderMarker !== lastTickCard.current && cardUnderMarker >= 0) {
        lastTickCard.current = cardUnderMarker;
        // speed = piksele przesunięte od ostatniej klatki / STRIDE
        const speed = Math.abs(pos - lastPos) / STRIDE;
        playTick(speed);
      }
      lastPos = pos;

      if (p < 1) { animRef.current = requestAnimationFrame(frame); }
      else { setPhase("reveal"); }
    };
    animRef.current = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(animRef.current);
  }, [phase]);

  useEffect(() => {
    if (phase === "reveal" && winner) {
      playReveal(winner.rarity);
    }
  }, [phase]);

  const claim = () => {
    if (!winner) return;
    setInventory(p => [...p, {...winner, uid: Date.now()+Math.random()}]);
    setTab("cases"); setPhase("idle"); setWinner(null);
  };

  const addSlot = (item) => {
    const idx = craftSlots.findIndex(s => s === null);
    if (idx === -1) return;
    const ns = [...craftSlots]; ns[idx] = item; setCraftSlots(ns); setCraftResult(null);
  };

  const removeSlot = (i) => {
    const ns = [...craftSlots]; ns[i] = null; setCraftSlots(ns); setCraftResult(null);
  };

  const synthesize = () => {
    const filled = craftSlots.filter(Boolean);
    if (filled.length < 2 || crafting) return;
    const syms = filled.map(e => e.symbol).sort();
    let hit = null;
    for (const rec of RECIPES) {
      if (JSON.stringify([...rec.inputs].sort()) === JSON.stringify(syms)) { hit = rec; break; }
    }
    setCrafting(true);
    setTimeout(() => {
      setCrafting(false);
      if (hit) {
        setCraftResult({ok:true, rec:hit});
        const usedUids = filled.map(e => e.uid);
        setInventory(p => {
          let rem = [...p];
          usedUids.forEach(uid => { const i = rem.findIndex(e => e.uid===uid); if(i!==-1) rem.splice(i,1); });
          rem.push({symbol:hit.formula, name:hit.name, z:"—", rarity:"epic", mass:"—", group:"Związek chem.", desc:hit.desc, emoji:hit.emoji, uid:Date.now(), isCompound:true});
          return rem;
        });
        setCraftSlots([null,null,null,null]);
      } else {
        setCraftResult({ok:false});
      }
    }, 1400);
  };

  const rarities = ["common","uncommon","rare","epic","legendary","contraband"];
  const invItems = invFilter === "all" ? inventory : inventory.filter(e => e.rarity === invFilter);

  return (
    <div style={{minHeight:"100vh",background:"#05050f",color:"#ddd",fontFamily:"'Segoe UI',system-ui,sans-serif",display:"flex",flexDirection:"column"}}>
      <style>{`
        @keyframes pop{from{transform:scale(0.6) translateY(20px);opacity:0}to{transform:scale(1) translateY(0);opacity:1}}
        @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}
        @keyframes glow{0%,100%{box-shadow:0 0 20px #a855f777}50%{box-shadow:0 0 40px #a855f7,0 0 80px #a855f744}}
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:#0a0a18}
        ::-webkit-scrollbar-thumb{background:#2a2a4a;border-radius:3px}
      `}</style>

      {/* ─ HEADER ─ */}
      <header style={{
        background:"linear-gradient(90deg,#05050f 0%,#0d0d28 50%,#05050f 100%)",
        borderBottom:"1px solid #ffffff0d",
        padding:"12px 20px",
        display:"flex", alignItems:"center", justifyContent:"space-between",
        position:"sticky", top:0, zIndex:200,
        gap:"10px", flexWrap:"wrap",
      }}>
        <div style={{display:"flex",alignItems:"center",gap:"10px"}}>
          <span style={{fontSize:"30px",filter:"drop-shadow(0 0 8px #5dade2)"}}>⚗️</span>
          <div>
            <div style={{fontWeight:900,fontSize:"17px",letterSpacing:"0.15em",background:"linear-gradient(90deg,#5dade2,#a855f7,#ec4899)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>
              CHEM CASE
            </div>
            <div style={{fontSize:"9px",color:"#444",letterSpacing:"0.3em"}}>CHEMISTRY CASE OPENER</div>
          </div>
        </div>

        <nav style={{display:"flex",gap:"4px",flexWrap:"wrap"}}>
          {[{id:"cases",lbl:"🧪 Skrzynki"},{id:"inventory",lbl:`🗂 Ekwipunek (${inventory.length})`},{id:"craft",lbl:"🔬 Synteza"}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{
              background:tab===t.id?"linear-gradient(135deg,#1a1a3e,#2d1a50)":"transparent",
              border:`1px solid ${tab===t.id?"#a855f7":"#ffffff15"}`,
              color:tab===t.id?"#c084fc":"#666",
              borderRadius:"8px", padding:"7px 14px",
              cursor:"pointer", fontSize:"12px", fontWeight:600,
              transition:"all 0.2s",
            }}>{t.lbl}</button>
          ))}
        </nav>

        <div style={{display:"flex",alignItems:"center",gap:"8px",background:"#0d0d1a",border:"1px solid #f59e0b33",borderRadius:"10px",padding:"6px 14px"}}>
          <span style={{fontSize:"18px"}}>🥈</span>
          <div>
            <div style={{fontWeight:700,color:"#f59e0b",fontSize:"15px",lineHeight:1}}>{coins}</div>
            <div style={{fontSize:"9px",color:"#555"}}>ARGENTUM</div>
          </div>
          <button onClick={()=>setCoins(c=>c+20)} style={{
            background:"linear-gradient(135deg,#0d2a0d,#1a3a1a)",
            border:"1px solid #22c55e55",color:"#22c55e",
            borderRadius:"6px",padding:"4px 10px",fontSize:"11px",cursor:"pointer",fontWeight:700,
          }}>+20</button>
        </div>
      </header>

      {/* ─ BODY ─ */}
      <main style={{flex:1,padding:"20px",maxWidth:"1100px",margin:"0 auto",width:"100%",boxSizing:"border-box"}}>

        {/* ══ CASES ══ */}
        {tab==="cases" && (
          <div>
            <div style={{color:"#444",fontSize:"11px",letterSpacing:"0.2em",textTransform:"uppercase",marginBottom:"20px"}}>
              Wybierz skrzynkę do otwarcia
            </div>
            <div style={{display:"flex",flexWrap:"wrap",gap:"14px",justifyContent:"center"}}>
              {CASES.map(c => (
                <CaseCardItem key={c.id} c={c} coins={coins} onOpen={openCase} />
              ))}
            </div>

            <div style={{marginTop:"44px"}}>
              <div style={{color:"#333",fontSize:"10px",letterSpacing:"0.2em",textTransform:"uppercase",marginBottom:"14px"}}>
                Wszystkie pierwiastki ({ELEMENTS.length})
              </div>
              <div style={{display:"flex",flexWrap:"wrap",gap:"5px"}}>
                {ELEMENTS.map(e=><ElCard key={e.symbol} el={e} size="sm" />)}
              </div>
            </div>
          </div>
        )}

        {/* ══ OPENING ══ */}
        {tab==="opening" && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:"28px"}}>
            {activeCase && (
              <div style={{textAlign:"center"}}>
                <div style={{fontSize:"44px",filter:`drop-shadow(0 0 12px ${activeCase.color})`}}>{activeCase.icon}</div>
                <div style={{color:activeCase.color,fontWeight:700,fontSize:"17px",marginTop:"6px"}}>{activeCase.name}</div>
              </div>
            )}

            {/* Strip */}
            <div ref={containerRef} style={{
              width:"100%",maxWidth:"860px",position:"relative",
              overflow:"hidden",height:"116px",
              background:"#080810",border:"1px solid #ffffff0a",borderRadius:"12px",
            }}>
              <div style={{position:"absolute",left:"50%",top:0,bottom:0,width:"2px",background:"linear-gradient(180deg,transparent,#f59e0b,transparent)",transform:"translateX(-50%)",zIndex:10}} />
              <div style={{position:"absolute",left:"50%",top:"-7px",transform:"translateX(-50%)",width:0,height:0,borderLeft:"8px solid transparent",borderRight:"8px solid transparent",borderTop:"8px solid #f59e0b",zIndex:11}} />
              <div style={{position:"absolute",left:0,top:0,bottom:0,width:"130px",background:"linear-gradient(90deg,#080810,transparent)",zIndex:9}} />
              <div style={{position:"absolute",right:0,top:0,bottom:0,width:"130px",background:"linear-gradient(-90deg,#080810,transparent)",zIndex:9}} />
              <div ref={stripRef} style={{display:"flex",position:"absolute",left:0,top:"8px",gap:"4px",willChange:"transform"}}>
                {strip.map((el,i)=>(
                  <div key={i} style={{flexShrink:0,width:"94px"}}>
                    <ElCard el={el} size="md" />
                  </div>
                ))}
              </div>
            </div>

            {phase==="spinning" && (
              <div style={{color:"#555",fontSize:"13px",letterSpacing:"0.15em",animation:"pulse 1s ease-in-out infinite"}}>
                Otwieranie skrzynki...
              </div>
            )}

            {phase==="reveal" && winner && (
              <div style={{
                background:`radial-gradient(ellipse at center, ${RARITY[winner.rarity].bg} 0%, #05050f 70%)`,
                border:`2px solid ${RARITY[winner.rarity].color}`,
                borderRadius:"20px",padding:"32px 36px",
                textAlign:"center",
                animation:"pop 0.5s cubic-bezier(0.34,1.56,0.64,1)",
                maxWidth:"400px",width:"100%",
                boxShadow:`0 0 80px ${RARITY[winner.rarity].glow}44`,
              }}>
                <div style={{display:"flex",justifyContent:"center",marginBottom:"20px",animation:"float 2.5s ease-in-out infinite"}}>
                  <ElCard el={winner} size="lg" />
                </div>
                <div style={{fontSize:"26px",fontWeight:900,color:RARITY[winner.rarity].color,marginBottom:"4px"}}>{winner.name}</div>
                <div style={{fontSize:"12px",color:"#777",marginBottom:"10px"}}>
                  {winner.symbol} · Z = {winner.z} · {winner.mass} u · {winner.group}
                </div>
                <div style={{
                  background:RARITY[winner.rarity].bg+"aa",
                  border:`1px solid ${RARITY[winner.rarity].color}44`,
                  borderRadius:"8px",padding:"10px 14px",
                  fontSize:"12px",color:"#bbb",marginBottom:"12px",lineHeight:1.65,
                }}>
                  {winner.desc}
                </div>
                <RarityBadge rarity={winner.rarity} />
                <div style={{marginTop:"20px",display:"flex",gap:"10px",justifyContent:"center"}}>
                  <button onClick={claim} style={{
                    background:`linear-gradient(135deg,${RARITY[winner.rarity].color}cc,${RARITY[winner.rarity].color}88)`,
                    border:`1px solid ${RARITY[winner.rarity].color}`,
                    color:"#fff",borderRadius:"10px",padding:"10px 28px",
                    fontWeight:700,fontSize:"14px",cursor:"pointer",
                    letterSpacing:"0.05em",
                  }}>Dodaj do ekwipunku →</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ INVENTORY ══ */}
        {tab==="inventory" && (
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"16px",flexWrap:"wrap",gap:"10px"}}>
              <div style={{color:"#444",fontSize:"11px",letterSpacing:"0.2em",textTransform:"uppercase"}}>
                Ekwipunek — {inventory.length} przedmiotów
              </div>
              <div style={{display:"flex",gap:"5px",flexWrap:"wrap"}}>
                {["all",...rarities].map(r=>(
                  <button key={r} onClick={()=>setInvFilter(r)} style={{
                    background:invFilter===r?(r==="all"?"#1a1a3e":RARITY[r]?.bg):"transparent",
                    border:`1px solid ${r==="all"?"#555":RARITY[r]?.color+"66"}`,
                    color:r==="all"?"#aaa":RARITY[r]?.color,
                    borderRadius:"6px",padding:"4px 10px",fontSize:"10px",
                    cursor:"pointer",fontWeight:600,
                  }}>{r==="all"?"Wszystko":RARITY[r].label}</button>
                ))}
              </div>
            </div>

            {invItems.length===0 ? (
              <div style={{textAlign:"center",color:"#333",padding:"70px 0"}}>
                <div style={{fontSize:"56px",marginBottom:"12px"}}>🗂</div>
                <div>{inventory.length===0?"Ekwipunek jest pusty — otwórz skrzynkę!":"Brak przedmiotów w tej kategorii."}</div>
              </div>
            ) : (
              <div style={{display:"flex",flexWrap:"wrap",gap:"10px"}}>
                {invItems.map(item=>{
                  const r = RARITY[item.rarity];
                  return (
                    <div key={item.uid} style={{
                      background:r.bg,
                      border:`1px solid ${r.color}55`,
                      borderRadius:"12px",padding:"14px",
                      width:"145px",
                      boxShadow:`0 0 10px ${r.color}22`,
                      display:"flex",flexDirection:"column",gap:"5px",
                    }}>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <div style={{fontSize:"22px",fontWeight:800,color:r.color,fontFamily:"monospace"}}>{item.emoji||item.symbol}</div>
                        <RarityBadge rarity={item.rarity} small />
                      </div>
                      <div style={{fontWeight:700,fontSize:"13px",color:"#e0e0e0",lineHeight:1.2}}>{item.name}</div>
                      <div style={{fontSize:"10px",color:"#666"}}>{item.group}</div>
                      <div style={{fontSize:"10px",color:"#555",lineHeight:1.45,flex:1}}>{item.desc?.substring(0,60)}…</div>
                      {!item.isCompound && (
                        <button onClick={()=>{addSlot(item);setTab("craft");}} style={{
                          background:"transparent",
                          border:`1px solid ${r.color}55`,color:r.color,
                          borderRadius:"6px",padding:"4px 0",
                          fontSize:"10px",cursor:"pointer",width:"100%",
                          marginTop:"4px",
                        }}>+ Do syntezy</button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ══ CRAFT ══ */}
        {tab==="craft" && (
          <div style={{display:"flex",gap:"24px",flexWrap:"wrap"}}>
            {/* Panel syntezy */}
            <div style={{flex:"0 0 320px",minWidth:"280px"}}>
              <div style={{color:"#444",fontSize:"11px",letterSpacing:"0.2em",textTransform:"uppercase",marginBottom:"14px"}}>
                Reagenty (przeciągnij maks. 4)
              </div>

              {/* Slots */}
              <div style={{display:"flex",gap:"8px",marginBottom:"16px",flexWrap:"wrap"}}>
                {craftSlots.map((slot,i)=>(
                  <div key={i} onClick={()=>slot&&removeSlot(i)} style={{
                    width:"72px",height:"72px",
                    background:slot?RARITY[slot.rarity].bg:"#0d0d1a",
                    border:`2px dashed ${slot?RARITY[slot.rarity].color:"#2a2a3e"}`,
                    borderRadius:"10px",
                    display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
                    cursor:slot?"pointer":"default",
                    transition:"all 0.2s",
                    boxShadow:slot?`0 0 12px ${RARITY[slot.rarity].color}44`:"none",
                    position:"relative",
                  }}>
                    {slot ? (
                      <>
                        <div style={{fontSize:"18px",fontWeight:800,color:RARITY[slot.rarity].color,fontFamily:"monospace"}}>{slot.symbol}</div>
                        <div style={{fontSize:"9px",color:"#888"}}>{slot.name}</div>
                        <div style={{position:"absolute",top:"2px",right:"5px",fontSize:"9px",color:"#f44"}}>✕</div>
                      </>
                    ) : (
                      <div style={{fontSize:"20px",color:"#222"}}>+</div>
                    )}
                  </div>
                ))}
              </div>

              <button onClick={synthesize} disabled={craftSlots.filter(Boolean).length<2||crafting} style={{
                width:"100%",
                background:crafting?"linear-gradient(135deg,#1a1a3e,#3a1a5e)":
                  craftSlots.filter(Boolean).length>=2?"linear-gradient(135deg,#2a0d4e,#5a1a8e)":"#0a0a18",
                border:`1px solid ${craftSlots.filter(Boolean).length>=2?"#a855f7":"#2a2a3e"}`,
                color:craftSlots.filter(Boolean).length>=2?"#c084fc":"#333",
                borderRadius:"10px",padding:"12px",
                fontSize:"14px",fontWeight:700,
                cursor:craftSlots.filter(Boolean).length>=2&&!crafting?"pointer":"not-allowed",
                letterSpacing:"0.1em",
                transition:"all 0.3s",
                animation:crafting?"glow 0.8s ease-in-out infinite":"none",
              }}>{crafting?"⚗️ Syntetyzuję...":"⚗️ SYNTETYZUJ"}</button>

              {craftResult && (
                <div style={{
                  marginTop:"14px",
                  background:craftResult.ok?"#0a1a0a":"#1a0a0a",
                  border:`1px solid ${craftResult.ok?"#22c55e":"#ef4444"}`,
                  borderRadius:"12px",padding:"16px",
                  animation:"pop 0.4s ease-out",
                }}>
                  {craftResult.ok ? (
                    <>
                      <div style={{fontSize:"30px",textAlign:"center"}}>{craftResult.rec.emoji}</div>
                      <div style={{color:"#22c55e",fontWeight:700,textAlign:"center",marginTop:"6px"}}>{craftResult.rec.name}</div>
                      <div style={{color:"#666",fontSize:"11px",textAlign:"center"}}>{craftResult.rec.formula}</div>
                      <div style={{color:"#aaa",fontSize:"11px",marginTop:"8px",lineHeight:1.55}}>{craftResult.rec.desc}</div>
                      <div style={{color:"#22c55e",fontSize:"11px",marginTop:"8px",textAlign:"center"}}>✓ Dodano do ekwipunku!</div>
                    </>
                  ) : (
                    <>
                      <div style={{fontSize:"28px",textAlign:"center"}}>💥</div>
                      <div style={{color:"#ef4444",fontWeight:700,textAlign:"center",marginTop:"6px"}}>Reakcja nieznana!</div>
                      <div style={{color:"#777",fontSize:"11px",textAlign:"center",marginTop:"4px"}}>Te pierwiastki nie tworzą związku. Sprawdź listę receptur!</div>
                    </>
                  )}
                </div>
              )}

              <div style={{marginTop:"20px"}}>
                <div style={{color:"#333",fontSize:"10px",letterSpacing:"0.15em",textTransform:"uppercase",marginBottom:"10px"}}>Znane receptury ({RECIPES.length})</div>
                <div style={{display:"flex",flexDirection:"column",gap:"5px",maxHeight:"280px",overflowY:"auto"}}>
                  {RECIPES.map(r=>(
                    <div key={r.formula} style={{
                      background:"#0a0a18",border:"1px solid #ffffff08",
                      borderRadius:"7px",padding:"6px 10px",
                      display:"flex",alignItems:"center",gap:"8px",
                    }}>
                      <span style={{fontSize:"13px"}}>{r.emoji}</span>
                      <span style={{color:"#ccc",fontSize:"11px",fontWeight:600,flex:1}}>{r.name}</span>
                      <span style={{color:"#444",fontSize:"10px"}}>{r.inputs.join("+")} </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Inventory picker */}
            <div style={{flex:1,minWidth:"200px"}}>
              <div style={{color:"#444",fontSize:"11px",letterSpacing:"0.2em",textTransform:"uppercase",marginBottom:"14px"}}>
                Twój ekwipunek — kliknij aby dodać
              </div>
              {inventory.filter(i=>!i.isCompound).length===0 ? (
                <div style={{color:"#2a2a3e",textAlign:"center",padding:"40px 0",fontSize:"13px"}}>
                  Ekwipunek jest pusty.<br/>Otwórz skrzynkę, aby zdobyć pierwiastki!
                </div>
              ) : (
                <div style={{display:"flex",flexWrap:"wrap",gap:"7px"}}>
                  {inventory.filter(i=>!i.isCompound).map(item=>{
                    const inSlot = craftSlots.some(s=>s?.uid===item.uid);
                    const full = craftSlots.every(Boolean);
                    return (
                      <div key={item.uid} onClick={()=>!inSlot&&!full&&addSlot(item)}
                        title={item.name+" — "+item.desc}
                        style={{cursor:inSlot||full?"default":"pointer"}}
                      >
                        <ElCard el={item} size="sm" selected={inSlot} dimmed={inSlot||full} />
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <footer style={{borderTop:"1px solid #ffffff07",padding:"10px 20px",textAlign:"center",color:"#2a2a3a",fontSize:"9px",letterSpacing:"0.15em"}}>
        CHEM CASE · {ELEMENTS.length} PIERWIASTKÓW · {RECIPES.length} RECEPTUR · PERIODIC TABLE EDITION
      </footer>
    </div>
  );
}